import { useState, useRef, useMemo } from "react";

interface BarChartProps {
  data: { day: string; value: number }[];
  color: string;
  maxOverride?: number;
  hourlyData?: Record<string, number[]>; // day -> 24 hourly values
}

export default function WeeklyBarChart({ data, color, hourlyData }: BarChartProps) {
  const [tooltip, setTooltip] = useState<{ index: number; x: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const maxVal = Math.max(...data.map(d => d.value), 1); // always >= 1, no divide by zero

  const todayIndex = useMemo(() => {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const today = (new Date().getDay() + 6) % 7;
    return data.findIndex(d => d.day === days[today]);
  }, [data]);

  const gridLines = [0.25, 0.5, 0.75];

  return (
    <div ref={containerRef} className="relative">
      {/* Grid lines */}
      <div className="absolute inset-0" style={{ height: 220 }}>
        {gridLines.map(pct => (
          <div
            key={pct}
            className="absolute left-0 right-0 border-t border-border"
            style={{ bottom: `${pct * 80 + 20}%`, opacity: 0.06 }}
          />
        ))}
      </div>

      <div className="relative flex items-end justify-between gap-2" style={{ height: 220 }}>
        {data.map((d, i) => {
          const height = (d.value / maxVal) * 80;
          const isToday = i === todayIndex;

          // Hourly micro histogram for this day
          const dayHourly = hourlyData?.[d.day];
          const maxHourly = dayHourly ? Math.max(...dayHourly, 1) : 1;

          return (
            <div
              key={d.day}
              className="flex flex-1 flex-col items-center gap-1"
              onClick={e => {
                const rect = (e.target as HTMLElement).getBoundingClientRect();
                const parentRect = containerRef.current?.getBoundingClientRect();
                if (parentRect) {
                  setTooltip(prev =>
                    prev?.index === i ? null : { index: i, x: rect.left - parentRect.left + rect.width / 2 }
                  );
                }
              }}
            >
              <div className="relative flex w-full flex-1 flex-col items-center justify-end">
                {/* Main bar */}
                <div
                  style={{
                    width: 22,
                    borderRadius: "12px 12px 0 0",
                    height: "100%",
                    transform: `scaleY(${d.value === 0 ? 0.02 : Math.min(Math.max((d.value / maxVal), 0.06), 1)})`,
                    transformOrigin: "bottom",
                    background: `linear-gradient(180deg, ${color}, ${color}50)`,
                    cursor: "pointer",
                    transition: "transform 600ms cubic-bezier(0.22,1,0.36,1)",
                    boxShadow: isToday ? `0 0 18px rgba(255, 59, 129, 0.45)` : "none",
                  }}
                />

                {/* Hourly micro histogram */}
                {dayHourly && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 flex gap-px items-end pointer-events-none"
                    style={{ height: `${height * 0.6}%`, width: "80%" }}
                  >
                    {dayHourly.map((hv, hi) => {
                      if (hv === 0) return null;
                      const microH = (hv / maxHourly) * 100;
                      return (
                        <div
                          key={hi}
                          className="flex-1 rounded-t-sm"
                          style={{
                            height: `${microH}%`,
                            backgroundColor: color,
                            opacity: 0.15 + (hv / maxHourly) * 0.3,
                          }}
                        />
                      );
                    })}
                  </div>
                )}
              </div>
              <span
                className="text-[10px] font-medium"
                style={{ color: isToday ? color : "hsl(var(--muted-foreground))" }}
              >
                {d.day}
              </span>
            </div>
          );
        })}
      </div>

      {/* Tooltip */}
      {tooltip !== null && (
        <div
          className="absolute -top-8 rounded-md bg-foreground px-2 py-1 text-xs font-bold text-background shadow-lg"
          style={{
            left: tooltip.x,
            transform: "translateX(-50%)",
            transition: "left 0.15s ease, opacity 0.15s ease",
          }}
        >
          {data[tooltip.index].value.toLocaleString()}
        </div>
      )}
    </div>
  );
}
